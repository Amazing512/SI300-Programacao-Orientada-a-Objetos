package org.unicamp.poo.util;

import static org.unicamp.poo.util.ConsoleColors.GREEN;
import static org.unicamp.poo.util.ConsoleColors.RESET;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.unicamp.poo.dao.TransactionDAO;
import org.unicamp.poo.dao.WalletDAO;
import org.unicamp.poo.model.TransactionFactory;
import org.unicamp.poo.model.Wallet;
import org.unicamp.poo.model.WalletFactory;

/**
 * Utilitário responsável pela carga inicial de dados (seeding) da aplicação.
 * Insere carteiras e movimentações fictícias para demonstração e testes caso a base esteja vazia.
 */
public final class DatabaseSeeder {
    private static final Logger log = LoggerFactory.getLogger(DatabaseSeeder.class);

    private DatabaseSeeder() {
    }

    /**
     * Executa a inserção de dados de exemplo (carteiras e transações históricas)
     * caso o banco de dados ainda não possua nenhum registro de carteira.
     *
     * @param walletDAO      o DAO de acesso às carteiras
     * @param transactionDAO o DAO de acesso às transações
     * @param messages       o provedor de mensagens para exibição de avisos no console
     */
    public static void seed(WalletDAO walletDAO, TransactionDAO transactionDAO, MessageProvider messages) {
        if (!walletDAO.findAll().isEmpty()) {
            log.debug("DatabaseSeeder: base de dados já possui registros. Seeding skippado.");
            return;
        }

        log.info("DatabaseSeeder: iniciando carga de dados");
        System.out.println(GREEN + messages.get("seeder.start") + RESET);

        LocalDate today = LocalDate.now();
        LocalDate yesterday = today.minusDays(1);
        LocalDate twoDaysAgo = today.minusDays(2);
        LocalDate threeDaysAgo = today.minusDays(3);
        LocalDate fourDaysAgo = today.minusDays(4);

        Wallet w1 = walletDAO.create(WalletFactory.create("Alice Silva", "Binance"));
        Wallet w2 = walletDAO.create(WalletFactory.create("Bob Santos", "Coinbase"));
        Wallet w3 = walletDAO.create(WalletFactory.create("Carol Costa", "Mercado Bitcoin"));

        if (w1 != null) {
            transactionDAO.create(TransactionFactory.createBuy(w1.getId(), threeDaysAgo, 10.0));
            transactionDAO.create(TransactionFactory.createBuy(w1.getId(), twoDaysAgo, 5.5));
            transactionDAO.create(TransactionFactory.createSell(w1.getId(), yesterday, 2.0));
        }

        if (w2 != null) {
            transactionDAO.create(TransactionFactory.createBuy(w2.getId(), fourDaysAgo, 20.0));
            transactionDAO.create(TransactionFactory.createSell(w2.getId(), twoDaysAgo, 5.0));
            transactionDAO.create(TransactionFactory.createSell(w2.getId(), yesterday, 3.0));
        }

        if (w3 != null) {
            transactionDAO.create(TransactionFactory.createBuy(w3.getId(), yesterday, 15.0));
            transactionDAO.create(TransactionFactory.createBuy(w3.getId(), today, 5.0));
        }

        log.info("DatabaseSeeder: carga de dados finalizada com sucesso.");
        System.out.println(GREEN + messages.get("seeder.success") + RESET);

        ConsoleScanner.pressEnterToContinue(messages.get("generic.pressEnter"));
        ConsoleScanner.clearScreen();
    }
}
